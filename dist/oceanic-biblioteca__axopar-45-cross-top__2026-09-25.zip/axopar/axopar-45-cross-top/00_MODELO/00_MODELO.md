# Axopar 45 Cross Top

## Identificación

| Campo | Valor | Fuente |
| --- | --- | --- |
| MARCA | Axopar (Axopar Boats Oy, Finlandia) | S1 |
| GAMA | Axopar 45 (Axopar 45 Cross Top, Axopar 45 Sun Top, Axopar 45 XC Cross Cabin) | S1 |
| MODEL | Axopar 45 Cross Top | S1 |
| MODEL YEAR | 2027 (campo `modelYear` de la ficha web) | S1 |
| VARIANT | Cross Top | S1 |
| TIPO | Motor (fueraborda) | S1 |
| PRECIO | NO ENCONTRADO (la web no publica precio) | S1 |
| URL OFICIAL | https://www.axopar.com/boat-models/axopar-45/axopar-45-cross-top/ | S1 |

## Reglas de alcance aplicadas

- Datos solo de la web oficial del producto (S1). Paquete generado por `tools/oceanic/builders/axopar.py`.
- No se mezclan otras variantes de la gama (Axopar 45 Sun Top, Axopar 45 XC Cross Cabin).
- Imágenes: 39 del modelo, 13 de otro modelo (excluidas), 9 por revisar, 0 no son del barco.

## Content readiness

<!-- READINESS:START (generado por `python -m oceanic readiness`, no editar) -->
**CONTENT_STATUS = YELLOW** · completitud 83% (informativa; el estado lo deciden las reglas)


| Grupo | Ítem | Estado | Detalle |
| --- | --- | --- | --- |
| DATOS | tabla_tecnica | PARTIAL | tabla base 7/8 verificada · faltan: capacidad_agua_dulce |
| DATOS | especificaciones | OK | 15 campos con fuente |
| DATOS | caracteristicas | OK | presente |
| DATOS | equipamiento | OK | standard.md, optional.md |
| EDITORIAL | hero | OK | 121 palabras fuente · candidato Oceanic presente |
| EDITORIAL | introduccion | OK | 197 palabras fuente · candidato Oceanic presente |
| EDITORIAL | diseno | OK | 357 palabras fuente · candidato Oceanic presente |
| EDITORIAL | ingenieria | OK | 106 palabras fuente · candidato Oceanic presente |
| EDITORIAL | experiencia | OK | 646 palabras fuente · candidato Oceanic presente |
| EDITORIAL | performance | OK | 108 palabras fuente · candidato Oceanic presente |
| MULTIMEDIA | hero_image | OK | 3 candidatas |
| MULTIMEDIA | exterior | OK | 10 en inventario (mín. 3) · descargadas 39/39 |
| MULTIMEDIA | interior | OK | 8 en inventario (mín. 2) · descargadas 39/39 |
| MULTIMEDIA | detail | OK | 12 en inventario (mín. 2) · descargadas 39/39 |
| MULTIMEDIA | video | OK | 3 videos del modelo |
| DOCUMENTOS | brochure | MISSING | no encontrado en fuentes oficiales |
| DOCUMENTOS | technical | MISSING | no encontrado en fuentes oficiales |
| DOCUMENTOS | manual | PARTIAL | 1 identificado(s) · requiere revisión |
<!-- READINESS:END -->

## Cruces de datos (tabla base)

- **Desplazamiento en rosca**: Weight (excl. Engine) → La web publica el peso del barco sin motores: es el peso en rosca.
- **Camarotes**: Front Cabin (Standard Features) → Cabina de proa de serie.
- **Camarotes**: Optional Equipment → Cabina de popa opcional.
- **Certificación**: Category + Passengers → Cruce de 'Category' y 'Passengers' en formato Oceanic (categoría + personas).
- **Potencia motor máx**: Outboard engines → Extremo superior de la motorización publicada.
- **Baños**: Standard Features → WC de serie en el equipamiento estándar.

## Información faltante o por revisar

- **Capacidad Agua Dulce** (NOT_FOUND): La web no publica un volumen de agua dulce (menciona: Freshwater system.).
- Traducción al español del equipamiento: pendiente.
- Brochure oficial: no encontrado en axopar.com.
- Manual del propietario: identificar en https://manuals.axopar.com/ (portal oficial).
