# INGENIERÍA · Antares 8

## SOURCE CONTENT

**A connected boat** — S1 (literal):

> The mobile application, Seanapps, and its onboard unit lets you view the status of the boat's various systems (battery charge, fuel or water tank levels, maintenance scheduling) via your smartphone, as well as planning your route or reviewing your sailing status using your mobile phone.

## OCEANIC CONTENT

> Candidato. Estado: **BORRADOR, requiere revisión editorial**.

> Casco abierto característico de Antares, de gran estabilidad y marinería. Puesto de gobierno ergonómico con panel de control de 12 pulgadas opcional. Admite aire acondicionado.
