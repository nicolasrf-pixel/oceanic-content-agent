# Antares 9

## Identificación

| Campo | Valor | Fuente |
| --- | --- | --- |
| MARCA | BENETEAU (Groupe Beneteau, Francia) | S1 |
| GAMA | Antares (Dayboats) | S1, S2 |
| MODEL | Antares 9 | S1 |
| MODEL YEAR | NO DECLARADO (la web del producto no declara model year) | S1 |
| VARIANT | Antares 9 | S1 |
| TIPO | Motor | S1 |
| PRECIO | From 141 500 € (VAT excluded) | S1 |
| URL OFICIAL | https://www.beneteau.com/antares/antares-9 | S1 |

## Reglas de alcance aplicadas

- Datos solo de la web oficial del producto (S1). Paquete generado por `tools/oceanic/builders/beneteau.py`.
- No se mezclan otros modelos de la gama (Antares 12 Coupe, Antares 7, Antares 7 Fishing, Antares 8, Antares 8 Fishing, Antares 11 Coupe, Antares 11 Fly, Antares 12 Fly).
- Imágenes: 31 del modelo, 0 de otro modelo (excluidas), 0 por revisar (compartidas con otras páginas), 1 no son del barco.

## Content readiness

<!-- READINESS:START (generado por `python -m oceanic readiness`, no editar) -->
**CONTENT_STATUS = YELLOW** · completitud 81% (informativa; el estado lo deciden las reglas)


| Grupo | Ítem | Estado | Detalle |
| --- | --- | --- | --- |
| DATOS | tabla_tecnica | PARTIAL | tabla base 6/8 verificada · faltan: camarotes, certificacion |
| DATOS | especificaciones | OK | 11 campos con fuente |
| DATOS | caracteristicas | OK | presente |
| DATOS | equipamiento | PARTIAL | optional.md |
| EDITORIAL | hero | OK | 72 palabras fuente · candidato Oceanic presente |
| EDITORIAL | introduccion | OK | 68 palabras fuente · candidato Oceanic presente |
| EDITORIAL | diseno | OK | 204 palabras fuente · candidato Oceanic presente |
| EDITORIAL | ingenieria | OK | 51 palabras fuente · candidato Oceanic presente |
| EDITORIAL | experiencia | OK | 179 palabras fuente · candidato Oceanic presente |
| EDITORIAL | performance | OK | 214 palabras fuente · candidato Oceanic presente |
| MULTIMEDIA | hero_image | OK | 3 candidatas |
| MULTIMEDIA | exterior | OK | 16 en inventario (mín. 3) · descargadas 30/31 |
| MULTIMEDIA | interior | OK | 9 en inventario (mín. 2) · descargadas 30/31 |
| MULTIMEDIA | detail | MISSING | 0 en inventario (mín. 2) · descargadas 30/31 |
| MULTIMEDIA | video | OK | 2 videos del modelo |
| DOCUMENTOS | brochure | MISSING | no encontrado en fuentes oficiales |
| DOCUMENTOS | technical | OK | 1 documento(s) con enlace oficial |
| DOCUMENTOS | manual | PARTIAL | 1 identificado(s) · requiere revisión |
<!-- READINESS:END -->

## Cruces de datos

- **Manga Casco**: Beam overall → 'Beam overall' (manga máxima) es la manga publicada del casco.
- **Desplazamiento en rosca**: Lightship Displacement → 'Lightship Displacement' = desplazamiento en rosca.
- **Arquitectura naval**: Créditos (descripción) → Créditos de arquitectura naval y diseño publicados junto a la descripción.
- **Motorización**: Max. engine power → Motorización = potencia máxima declarada en 'Max. engine power'.
- **Autonomía**: Texto de la página → Autonomía declarada por el fabricante en el texto, con su condición de velocidad.

## Información faltante o por revisar

- **Camarotes** (NOT_FOUND): No publicado en la web oficial del producto.
- **Certificación** (NOT_FOUND): No publicado en la web oficial del producto.
- Equipamiento: la web no publica lista standard; ver la lista de equipamiento PDF en 06_DOCUMENTOS (documento, no aporta datos).
- Traducción al español del equipamiento: pendiente.
- Manual del propietario: identificar en el Help Center oficial (help.beneteau.com).
