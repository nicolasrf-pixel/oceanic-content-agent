# Mapa de fuentes · Gran Turismo 40 Open

Todos los datos y textos salen de S1 (https://www.beneteau.com/new-gran-turismo-range/gran-turismo-40-open), accedida 2026-09-27 con Firecrawl (rawHtml). S2 es la página de gama (referencia).
