# Mapa de fuentes · Oceanis Yacht 54

Todos los datos y textos salen de S1 (https://www.beneteau.com/oceanis-yacht/oceanis-yacht-54), accedida 2026-09-27 con Firecrawl (rawHtml). S2 es la página de gama (referencia).
